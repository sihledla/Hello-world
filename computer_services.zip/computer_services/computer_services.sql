-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 20, 2016 at 04:32 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `computer_services`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(5) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `fullName`, `username`, `password`) VALUES
(1, 'Thokozani Dlamini', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `computer`
--

CREATE TABLE IF NOT EXISTS `computer` (
  `sNumber` varchar(50) NOT NULL,
  `cName` varchar(50) NOT NULL,
  `make` varchar(50) NOT NULL,
  `ministry` varchar(50) NOT NULL,
  `os` varchar(50) NOT NULL,
  `software` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `offNumber` char(10) NOT NULL,
  PRIMARY KEY (`sNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `computer`
--

INSERT INTO `computer` (`sNumber`, `cName`, `make`, `ministry`, `os`, `software`, `username`, `offNumber`) VALUES
('00000000', 'HA-MBA-5007', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2007,Symantec64bit', '  dlaminigu', '143'),
('0311192100445', 'CS-MBA-G612', 'LENOVO', 'Ministry of Information, Communications and Techno', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', ' Mabuya', '18'),
('1115TDTO2905', 'HA-MBA-2905', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2003,Symantec32bit', ' shongwet', '129'),
('1154732', 'CM-MBA-4732', 'DELL', 'Ministry of Commerce, Industry and Trade', 'Windows7', 'Entire,Office2013', 'matsebulaba', '315'),
('1210TDT04897', 'JU-MBA-4987', 'ACER', 'Ministry of Justice', 'Windows 7', 'Office2003,Symantec32bit', ' seabo', '502'),
('1210TDT05031', 'CM-MBA-5031', 'ACER', 'Ministry of Commerce, Industry and Trade', 'Windows7', 'Entire,Office2003,Symantec32bit', 'Mdlovu Sibongile', '317'),
('1210TDT05036', 'HA-MBA-5036', 'ACER', 'Ministry of Home Affairs', 'Windows 8', 'Entire,Office2010,Symantec32bit', ' mabasot', 'Hon. Minis'),
('1210TDT05085', 'HA-MBA-5083', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2007,Symantec32bit', ' George Mkhabela', '124'),
('1210TDT05154', 'HA-MBA-UH86', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2013,Symantec32bit', ' Nomvula Agnes Dlamini', '301'),
('1210TDT05216', 'HA-MBA-5216', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2003,Symantec32bit', ' mndzebeletre', '138'),
('1MW3DY1', 'ED-MBA-3DY1', 'DELL', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2013,Symantec32bit', ' manyatsis', '112'),
('30Z2DY1', 'JU-MBA-4953', 'DELL', 'Ministry of Justice', 'Windows 8', 'Entire,Office2010,Symantec64bit', ' dlamininno', '404'),
('3CB0232JXG', 'CS-MBA-2JXG', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2013,Symantec64bit', 'mavimbelasa', '26'),
('3CB0232M5C', 'EDU-MBA-2M5C', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Office2007,Symantec32bit', ' dlamini nonhlanhla', '115'),
('3CB09H22YS', 'HA-MBA-22YS', 'HP', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2003,Office2007,Symantec32bit', ' SIPHILA MNTJALI', '136'),
('3CB76G5220', 'JU-MBA-5220', 'ACER', 'Ministry of Justice', 'Windows 7', 'Office2010,Symantec32bit', ' hlatjwayosibo', '148'),
('3CB84522GN', 'EDU-MBA-22GN', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Entire,Office2003,Symantec32bit', ' Shongwe Ruth', '310'),
('3CB84522HP', 'CS-MBA-22HP', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2007,Symantec32bit', 'sambon', '1'),
('3CB84522HR', 'ict-mba-22hr', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Office2007,Symantec32bit', 'Legal Advisor', '13'),
('3CB84522LW', 'EDU-MBA-22WL', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Entire,Office2003,Office2007,Symantec32bit', ' mansoorn', '110'),
('3cb84522n7', 'cs-mba-22n7', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Symantec32bit', 'none', '16'),
('3cb84522nr', 'ict-mba-22nr', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2007', 'sifundzav', '11'),
('3cb84522nx', 'ict-mba-22nx', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Office2007,Symantec32bit', 'dlaminisak', '08'),
('3cb84522p0', 'CS-MBA-22PO', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Entire,Office2003,Symantec32bit', 'vilakatigc', '14'),
('3CB84522Q5', 'CS-MBA-22Q5', 'HP', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'mdlulis', '8'),
('3CB84522TZ', 'CM-MBA-626B', 'HP', 'Ministry of Commerce, Industry and Trade', 'WindowsXP', 'Entire,Office2003,Symantec32bit', 'Mavuso Mduduzi', '306'),
('3cb84522vp', 'ha-mba-22vp', 'HP', 'Ministry of Home Affairs', 'Windows XP', 'Office2003,Office2007', ' magagulac', '305'),
('3CB84532KF', 'ICT-MBA-23W6', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Entire,Office2007,Symantec32bit', 'dlaminitem', '24'),
('3CB90324BL', 'EDU-MBA-254Y', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Entire,Office2007,Symantec32bit', ' inampasa', '218'),
('3CB90324KZ', 'ED-MBA-2', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Entire,Office2003,Symantec32bit', ' mansoorn', '110'),
('3CB90324RC', 'ED-MBA-24RC', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Office2007,Symantec32bit', ' hlophebh', '515'),
('3CB90324SS', 'EDU-MBA-W897', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Entire,Office2003,Symantec32bit', ' Dlamini Busiso', '310'),
('3CB9032505', 'ED-MBA-2505', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Office2013,Symantec32bit', ' Angel dlamini', '115'),
('3CB9032514', 'EDU-MBA-2514', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Office2007', ' Nurse Motsa', '304'),
('3CB903254X', 'EDU-MBA-254X', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Entire,Office2003,Symantec32bit', ' Nkambule Lindiwe', '310'),
('3CB90723PG', 'CS-MBA-23PG', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Office2007', 'simelanemuz', '12'),
('3cb90723rm', 'ict-mba-7654', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2007,Symantec64bit', 'nkambulenon', '9'),
('3cb90723v8', 'ict-mba-23v8', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2010,Symantec64bit', 'mamba mbongeni', '07'),
('3CB90723W6', 'ICT-MBA-23W6', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Entire,Office2003,Symantec32bit', 'yenden', '24'),
('3CB907240T', 'cs-mba-24ot', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Entire,Office2013,Symantec64bit', 'fakudzem', '2'),
('3CB907247P', 'ICT-MBA-247P', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Entire,Office2003,Symantec32bit', 'DLAMINIHA', '23'),
('3CB91125Z2', 'EDU-MBA-25Z2', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Office2013', ' methulasik', '414'),
('3CB91125ZP', 'ED-MBA-25ZP', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Office2007,Symantec32bit', ' khumalompe', '213'),
('3CB91125ZV', 'ED-MBA-25ZV', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Entire,Office2007', ' Busiso Dlamini', '310'),
('3CB91126J2', 'ED-MBA-26J2', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Office2007', ' Zwane Vuyisile', '511'),
('3CB91322X6', 'ICT-MBA-22X6', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Entire,Office2007,Symantec32bit', 'DLAMINI NOMPHUMELELO', '22'),
('3CB913238W', 'ICT-MBA-CB91', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Office2007,Symantec32bit', 'Bikiswa', '30'),
('3CB913247H', 'ICT-MBA-247H', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Entire,Office2003,Office2007,Symantec32bit', 'hlophea', '31'),
('3CB92129T5', 'ED-MBA-29T5', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Office2007', ' Phumzile Magugala', '616'),
('3CB93320Q2', 'ED-MBA-20Q2', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Office2007,Symantec32bit', ' Dlamini Herbert ', '204'),
('3CB93422WG', 'ED-MBA-22WG', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Office2007,Symantec32bit', ' mdlulifi', '222'),
('3CB93422XB', 'EDU-MBA-22XB', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Office2007,Symantec32bit', ' gamendzet', '208'),
('3CB93821WM', 'CM-MBA-21WM', 'HP', 'Ministry of Commerce, Industry and Trade', 'WindowsXP', 'Entire,Office2007,Symantec32bit', 'administrator', '308'),
('3CB9412418', 'JU-MBA-2418', 'HP', 'Ministry of Justice', 'Windows XP', 'Entire,Office2007,Symantec32bit', ' dlaminimaj', 'ARTTONEY'),
('3CB9412419', 'cs-mba-2419', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Entire,Office2010', 'campk', '16'),
('3CB941241D', 'JU-MBA-241D', 'HP', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2013,Symantec32bit', ' simelanet', '406'),
('3CB94124NR', 'JU-MBA-4LJR', 'HP', 'Ministry of Justice', 'Windows 7', 'Office2010,Symantec32bit', ' khumalogu', '412'),
('3CB9412577', 'JU-MBA-2577', 'HP', 'Ministry of Justice', 'Windows 7', 'Office2007', ' khumalonf', 'Attorney G'),
('3s5gg2806', 'HA-MBA-2806', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2007,Symantec32bit', 'dlamini mduduzi', '139'),
('43W3DY1', 'ED-MBA-43W3', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Office2013,Symantec64bit', ' ngcamphalalaw', '316'),
('4CE0420DDS', 'HA-MBA-ODDS', 'HP', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2010,Symantec64bit', ' Dlamini Hyness', '320'),
('4CE0420DDY', 'HA-MBA-0DDY', 'HP', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2003,Symantec32bit', ' Administrator', '319'),
('4DT101J', 'ED-MBA-101J', 'DELL', 'Ministry of Education and Training', 'Windows XP', 'Office2003,Office2007,Symantec32bit', ' Kunene Bongiwe', '511'),
('4QQ5DY1', 'JU-MBA-1236', 'DELL', 'Ministry of Justice', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', ' dlaminipric', '437'),
('4XY2DY1', ' JU-MBA-1481', 'DELL', 'Ministry of Justice', 'Windows 8', 'Office2013,Symantec64bit', ' mlamboz', 'none'),
('50z2dy1', 'ju-mba-2dy1', 'DELL', 'Ministry of Justice', 'Windows 8', 'Office2013,Symantec64bit', ' vilakatitho', '410'),
('5CG5520568', 'GCS-APPL-HP', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2013,Symantec64bit', 'Michael Cebe', '10'),
('5cg552056z', 'CS-MBA-056Z', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Entire,Office2013,Symantec64bit', 'vilakatis', 'Director'),
('5GW3DY1', 'EDU-MBA-5GW3', 'DELL', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2013,Symantec64bit', ' masekomu', '112'),
('5LQ5DY1', 'JU-MBA-2745', 'DELL', 'Ministry of Justice', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' Principal Secretary', '527'),
('60Z2DY1', 'JU-MBA-1961', 'DELL', 'Ministry of Justice', 'Windows 8', 'Entire,Office2007,Office2013', ' Simelane Sanele', '525'),
('66W3DY1', 'ED-MBA-3DY1', 'DELL', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2003,Symantec64bit', ' Dlamini Clement', '506'),
('6cr2500kd7', 'cs-mba-0kd7', 'HP', 'Ministry of Information, Communications and Techno', 'Windows10', 'Office2013', 'dlaminibon', '2'),
('6CR2500KDN', 'HA-MBA-7T77', 'HP', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2013,Symantec32bit', ' simelanenomb', '123'),
('6CR2500KFZ', 'HA-MBA-0KFZ', 'HP', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2013,Symantec64bit', ' dlaminibhe', '125'),
('6CR2500KHL', 'ED-MBA-0KHL', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Office2013,Symantec32bit', ' dlaminicelu', '606'),
('70Z2DY1', 'JU-MBA-4297', 'DELL', 'Ministry of Justice', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' dlaminindabenhle', '426'),
('7YV3DY1', 'ED-MBA-3DY1', 'DELL', 'Ministry of Education and Training', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', '  dlaminicons', '316'),
('8H0QB22', 'ICT-MBA-1066', 'DELL', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'dladlaba', '28'),
('8LQ5DY1', 'JU-MBA-9753', 'DELL', 'Ministry of Justice', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' Zwakele Dlamini', '519'),
('8ZV3DY1', 'ED-MBA-3DY1', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Office2013,Symantec64bit', ' Mamba Lungile', '414'),
('9BD54Y1', '9BD54Y1', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013,Symantec64bit', 'dlaminimz', '13'),
('9BW3DY1', 'ED-MBA-3DY1', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' Shiba Sheena', '110'),
('9G0HB32', 'ED-MBA-HB32', 'DELL', 'Ministry of Education and Training', 'Windows 7', 'Office2013,Symantec64bit', 'Dhlomo', '220'),
('9HQ5DY1', 'JU-MBA-7385', 'DELL', 'Ministry of Justice', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' nsibandzeg', '502'),
('9LQ5DY1', 'JU-MBA-5DY1', 'DELL', 'Ministry of Justice', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' khumalosif', 'DAG'),
('9VY2DY1', 'JU-MBA-0809', 'DELL', 'Ministry of Justice', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' nkambulebi', '505'),
('A00000000', 'HA-MBA-4WGD', 'HP', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2003,Symantec64bit', ' shongwett', '143'),
('B90324YB', 'ED-MBA-24YD', 'HP', 'Ministry of Education and Training', 'Windows XP', 'Entire,Office2003', ' Nomvula Simelane', '310'),
('C5W3DY1', 'ED-MBA-C5W3', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' mbulim', '111'),
('CND52063G8', 'CS-MBA-63G8', 'HP', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013', 'dlaminbon', '5'),
('CND52063GN', 'cs-mba-63gn', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013,Symantec64bit', 'Thembumusa Simelane', '8'),
('cnd52065tc', 'cs-mba-65tc', 'HP', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'malazag', '14'),
('CND52065TT', 'CS-MBA-65TT', 'HP', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'magongog', '06'),
('cnd520665l', 'CS-MBS-665L', 'HP', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013,Symantec64bit', 'mdluliml', '8'),
('CND52066MS', 'cs-mba-66ms', 'HP', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2010,Symantec64bit', 'nkwanyanad', '27'),
('CND52066N7', 'CS-MBA-66N7', 'HP', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2003,Office2010', 'Sipho Mamba', '21'),
('CND5343BMM', 'CS-MBA-3BMM', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Entire,Office2013,Symantec64bit', 'simelanemuz', '12'),
('cnu9279716', 'CS-MBA-9816', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2010,Symantec32bit', 'vilakatis', 'Director'),
('DF345M64NU880', 'HA-MBA-U880', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Office2010,Symantec64bit', 'dlaminisamuh', '126'),
('DK44732', 'HA-MBA-8158', 'DELL', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2007,Symantec32bit', ' Sthemiso Sukati', '312'),
('DYV3DY1', 'ED-MBA-DYV3', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' ginindzane', '413'),
('F1TGE7Z07Z9520BABE2700', 'COM-MBA-2700', 'ACER', 'Ministry of Commerce, Industry and Trade', 'Windows7', 'Entire,Office2010,Symantec32bit', 'administrator', '301'),
('FXY2DY1', 'JU-MBA-7177', 'DELL', 'Ministry of Justice', 'Windows 8', 'Entire,Office2013,Symantec32bit', ' nxumaloda', '428'),
('G4W3DY1', 'ED-MBA-G4W3', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' dlaminimph', '110'),
('G7BNB22', 'CS-MBA-NB22', 'DELL', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'mlotsami', '1'),
('GJQ5DY1', 'JU-MBA-6089', 'DELL', 'Ministry of Justice', 'Windows 8', 'Office2013,Symantec64bit', 'ndlelew', '409'),
('guihw8tr745654rn2120', 'COM-MBA-2120', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2010', 'sibandzem', '314'),
('GXYDY1', 'JU-MBA-9513', 'DELL', 'Ministry of Justice', 'Windows 8', 'Office2010,Symantec32bit', ' simelanet', '411'),
('H0W3DY1', 'ED-MBA-H0W3', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' mabuzanon', '302'),
('HGGF7KI99997226', 'HA-MBA-7226', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2003,Symantec64bit', 'khumaloj', '322'),
('HKQ5DY1', 'JU-MBA-4601', 'DELL', 'Ministry of Justice', 'Windows 8', 'Entire,Office2013', ' Dudu Mthembu', '519'),
('HLW3DY1', 'ED-MBA-HLW3', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' Gwebuc', '112'),
('HYY2DY1', 'JU-MBA-8025', 'DELL', 'Ministry of Justice', 'Windows 8.1', 'Office2013,Symantec64bit', ' Mngomezulu Khumbulani', '416'),
('J2W3DY1', 'ED-MBA-J2W3', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' Mamba Dumisani', '105'),
('JENB91ID900332', 'CS-MBA-0332', 'OTHER', 'Ministry of Information, Communications and Techno', 'Windows8', 'Office2010', 'mavusoc', '4'),
('JGW3DY1', 'ED-MBA-JGW3', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Entire,Office2013,Symantec64bit', ' dlaminivz', '301'),
('JHW3DY1', 'ED-MBA-JHW3', 'DELL', 'Ministry of Education and Training', 'Windows 8', 'Entire,Office2010,Symantec64bit', '  vilakatisi', '413'),
('JLQ5DY1', 'JU-MBA-5DY1', 'DELL', 'Ministry of Justice', 'Windows 8', 'Office2010', ' Nxumalo Khetho', '415'),
('JVY2DY1', 'JU-MBA-5437', 'DELL', 'Ministry of Justice', 'Windows 8', 'Office2013,Symantec64bit', ' magaguladan', '427'),
('p1tge7z0729520babb2700', 'CS-MBA-2700', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Entire,Office2003,Symantec32bit', 'operator', 'server roo'),
('P1TGE7Z07Z0130246B2700', 'EDU-MBA-2327', 'ACER', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2007,Symantec32bit', ' groeningb', '405'),
('P1TGE7Z07Z013025FF2700', 'HA-MBA-3025', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2003,Office2010,Symantec32bit', ' Administrator', '144'),
('P1TGE7Z07Z9470CC9227000', 'CS-MBA-Z947', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2010,Symantec32bit', 'mthimkhulubu', '7'),
('P1TGE7Z07Z9470CC9A2700', 'EDU-MBA-2700', 'ACER', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2003,Symantec32bit', ' Ndzabukelwako Bagezile', '414'),
('P1TGE7Z07Z9470CC9C2700', 'CS-MBA-C270', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows7', 'Entire,Office2010,Symantec64bit', 'makhubuem', '29'),
('P1TGE7Z07Z9470CCA92700', 'HA-MBA-8UW9', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2007', ' magagulast', '302'),
('P1TGE7Z07Z9520BAD32700', 'CS-MBA-0808', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2013,Symantec64bit', 'Phiwayinkhosi', '8'),
('p1tge7z07z9520baf02700', 'CS-MBA-AC01', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2013,Symantec32bit', 'shongwemo', '10'),
('P1TGE7Z07Z9520BB042700', 'CS-MBA-TWO2', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013,Symantec64bit', 'dludlusa', '2'),
('P1TGE7Z07Z9520BB072700', 'testPC', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'Msimisi', '8'),
('P1TGE7Z07Z9520BB272700', 'CS-MBA-2700', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows7', 'Entire,Office2013,Symantec64bit', 'Michael Cebe', '10'),
('P1TGE7Z9520BA192700', 'JU-MBA-1927', 'ACER', 'Ministry of Justice', 'Windows 8', 'Entire,Office2010,Symantec64bit', ' masekoja', '304'),
('p1tge7ze07z9520bad62700', 'CS-MBA-2700', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2010,Symantec64bit', 'Sbongkhosi Shongwe', '17'),
('p1tgge7zo7z9520ba072700', 'CS-MBA-2700', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows10', 'Office2013', 'Sbongkhosi Shongwe', '17'),
('PC07G6F2', 'CS-MBA-G6F2', 'LENOVO', 'Ministry of Information, Communications and Techno', 'Windows10', 'Entire,Office2013', 'dlaminivuy', '14'),
('PC07G6G9', 'CS-MB-G6G9', 'LENOVO', 'Ministry of Information, Communications and Techno', 'Windows10', 'Office2013', 'fakudzeb', '14'),
('PC07G6GL', 'CS-MBA-GGGL', 'LENOVO', 'Ministry of Information, Communications and Techno', 'Windows10', 'Entire,Office2003,Office2013', 'shabangum', '18'),
('PC07G6JR', 'CS-MBA-G6JR', 'LENOVO', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2013,Symantec32bit', 'mkelev', '13'),
('PC07G6JT', 'CS-MBA-G6JT', 'LENOVO', 'Ministry of Information, Communications and Techno', 'Windows10', 'Entire,Office2013', 'ndzinisak', '12'),
('PF1L01T', 'CS-MBA-L01T', 'LENOVO', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013', 'simelanemuz', '12'),
('rterte3t4drt2813', 'HA-MBA-2813', 'ACER', 'Ministry of Commerce, Industry and Trade', 'Windows7', 'Entire,Office2003,Symantec64bit', 'Mbali Nsibande', '312'),
('S1LKN57', 'CS-MBA-KN57', 'LENOVO', 'Ministry of Information, Communications and Techno', 'Windows8', 'Entire,Office2013,Symantec64bit', 'nxumaloxo', '11'),
('S1LKN65', 'CS-MBA-KN65', 'LENOVO', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013,Symantec64bit', 'gamasp', '1'),
('S1LKN70', 'CS-MBA-KN70', 'LENOVO', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013', 'lukhelete', '14'),
('sd35kly787g0', 'HA-MBA-87G0', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2007,Symantec64bit', ' SALAPHI DLAMINI', '150'),
('SRQTA025408260080000', 'CS-MBA-0000', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013', 'dlaminisipho', '26'),
('TRF2040', 'ED-MBA-W5N', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Office2010,Symantec32bit', ' nxumaloceb', '215'),
('TRF2040w50', 'ED-MBA-OW50', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2010,Symantec32bit', ' mtshalins', '415'),
('TRF2040W53', 'EDU-MBA-05W3', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2010,Symantec32bit', ' mambantom', '310'),
('TRF2040W5F', 'EDU-MBA-0W5F', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2010,Symantec32bit', ' hlobie01', '410'),
('TRF2040W5G', 'EDU-MBA-0W5G', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2003,Symantec32bit', '  mambabu', '405'),
('TRF2040W5V', 'EDU-MBA-0W5V', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2010,Symantec32bit', ' mavimbelagci', '406'),
('TRF2040W60', 'EDU-MBA-0W60', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2013,Symantec32bit', ' dlaminipercy', '406'),
('TRF2040W6B', 'ED-MBA-0W6B', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Office2010,Symantec32bit', ' simelanewe', '206'),
('TRF2040W75', 'ED-MBA-0W75', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Office2010,Symantec32bit', ' mkhatshwawe', '403'),
('TRF2040W76', 'EDU-MBA-0W76', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2010,Symantec32bit', ' mhlangath', '412'),
('TRF2040W7F', 'ED-MBA-0W7F', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2003,Symantec64bit', ' Khumalop', '410'),
('TRF2040W7M', 'ED-MBA-0W7M', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2010,Symantec32bit', ' ndzinisasibu', '416'),
('TRF20440W5M', 'ED-MBA-0W5M', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2010,Symantec32bit', ' vilanekho', '412'),
('TRF3340ZDV', 'HE-MBA-2487', 'ACER', 'Ministry of Health', 'Windows7', 'Office2007,Symantec64bit', 'dlaminiedmu', '516'),
('TRF4130LXV', 'HA-MBA-0LXV', 'HP', 'Ministry of Home Affairs', 'Windows 7', 'Entire,Office2003,Office2013,Symantec64bit', ' makhubunana', '324'),
('TRF5350DJ4', 'CS-MBA-3005', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2013', 'masekosi', '13'),
('TRF5370JWN', 'ED-MBA-0JWN', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2013', ' malazath', '305'),
('TYTGFD52925', 'JU-MBA-2925', 'ACER', 'Ministry of Justice', 'Windows 7', 'Entire,Office2003', ' Christopher Magagula', '526'),
('UDSDRQTA02540825F810000', 'HA-MBA-F810', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2003,Symantec64bit', 'MHLONGOEU', '136'),
('UDSRKTA02540825F970000', 'ED-MBA-F970', 'ACER', 'Ministry of Education and Training', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', ' mnyandun', '412'),
('UDSRQTA02540025FCF0000', 'CS-MBA-FF20', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows10', 'Office2003,Office2013,Symantec64bit', 'dlaminicyr', '2'),
('UDSRQTA0254082260440000', 'ED-MBA-1600', 'ACER', 'Ministry of Education and Training', 'Windows 8.1', 'Office2013,Symantec64bit', ' Manana Busi', '304'),
('UDSRQTA02540825F700000', 'HA-MBA-0000', 'ACER', 'Ministry of Home Affairs', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', ' Hlophe Busisiswe', '135'),
('udsrqta02540825f730000', 'ict-mba-0700', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'ndzinisanq', '21'),
('UDSRQTA02540825F790000', 'cs-mba-5f79', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013', 'shabanguno', '13'),
('UDSRQTA02540825F7D0000', 'HA-MBA-889Y', 'ACER', 'Ministry of Home Affairs', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', ' Dlaminippj', '332'),
('UDSRQTA02540825F860000', 'HA-MBA-5F86', 'ACER', 'Ministry of Home Affairs', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', ' Jabu N Mlambo', '156'),
('UDSRQTA02540825FA90000', 'EDU-MBA-25FA', 'ACER', 'Ministry of Education and Training', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', ' ncongwanef', '402'),
('UDSRQTA02540825FB40000', 'EDU-MBA-UDSR', 'ACER', 'Ministry of Education and Training', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', ' magagulab', '406'),
('udsrqta02540825fc90000', 'ict-mba-9300', 'HP', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'shabangugp', '20'),
('UDSRQTA02540825FF00000', 'ED-MBA-3200', 'ACER', 'Ministry of Education and Training', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', ' maphosam', '114'),
('udsrqta02540825ff70000', 'cs-mba-5ff7', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013,Symantec64bit', 'makhubuth', '6'),
('UDSRQTA02540825FF90000', 'CS-MBA-0000', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8', 'Office2013', 'reception', '28'),
('UDSRQTA0254082601', 'cs-mba-60190', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'dlaminicelumu', '12'),
('UDSRQTA025408260130000', 'CS-MBA-6013', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013,Symantec64bit', 'vilakatisib', '12'),
('udsrqta02540826037', 'ict-mba-6037', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2003,Symantec64bit', 'motsas', '12'),
('UDSRQTA025408260380000', 'HA-MBA-0400', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'dlaminifel', '142'),
('UDSRQTA0254082604F0000', 'HA-MBA-7668', 'ACER', 'Ministry of Home Affairs', 'Windows 8.1', 'Entire,Office2003,Symantec64bit', ' James vilakati', '154'),
('UDSRQTA025FF50000', 'HA-MBA-25ff', 'ACER', 'Ministry of Home Affairs', 'Windows 8.1', 'Entire,Office2010', ' Zwane Sthembile', '143'),
('UDSRQTA0445110014D0001', 'ICT-MBA-00TJ', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'dlaminitj', '27'),
('UDSRQTA0445110016F0001', 'ICT-MBA-0001', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013,Symantec64bit', 'SITHOLENT', 'MINISTERS'),
('UDSRQTA044511001A20001', 'ict-mba-1a20', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013,Symantec64bit', 'minister_ict', '1'),
('udsrqta04451100660001', 'cs-mba-qta0', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'dlaminisiph', '09'),
('udsrqta44511001650001', 'ict-mba-rq02', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'dubephe', '14'),
('UDSRQTAO44511001870001', 'ICT-MBA-0001', 'ACER', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2013,Symantec64bit', 'SIBIYAPH', '04'),
('UDSRTA0250825FA30000', 'ED-MBA-5500', 'ACER', 'Ministry of Education and Training', 'Windows 8.1', 'Entire,Office2013,Symantec64bit', ' khumaloma', '114'),
('USDB34H23J1NC22XG', 'HA-MBA-22XG', 'ACER', 'Ministry of Home Affairs', 'Windows 7', 'Office2007,Symantec32bit', ' mabasot', '131'),
('ZAB45001TJ', 'HA-MBA-01TJ', 'HP', 'Ministry of Home Affairs', 'Windows XP', 'Office2007', ' Stephen', '302'),
('ZAB513001S', 'CS-MBA-OP01', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Symantec32bit', 'MAZIBUKOSD', '6'),
('zab602020h', 'cs-mba-020h', 'HP', 'Ministry of Information, Communications and Techno', 'WindowsXP', 'Office2003,Symantec32bit', 'smatrice simela', '16'),
('ZAB64700ZF', 'JU-MBA-00ZF', 'HP', 'Ministry of Justice', 'Windows XP', 'Office2007,Symantec32bit', ' nkambuleflo', '517'),
('ZAB713018K', 'CS-MBA-018K', 'HP', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Office2003,Office2010,Symantec32bit', 'mambase', '5'),
('ZAB7170195', 'HA-MBA-7019', 'HP', 'Ministry of Home Affairs', 'Windows XP', 'Entire,Office2003,Symantec32bit', ' Bongiwe G Motsa', '306'),
('zab71701bh', 'cs-mba-01bh', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Entire,Office2013,Symantec64bit', 'magongog', '6'),
('ZAB722900J5', 'cs-mba-00j5', 'HP', 'Ministry of Information, Communications and Techno', 'Windows8.1', 'Entire,Office2013,Symantec64bit', 'dubem', '2'),
('ZAB72900J8', 'CS-MBA-00J8', 'HP', 'Ministry of Information, Communications and Techno', 'Windows7', 'Office2013', 'dlaminibon', '2'),
('ZAB7480068', 'HA-MBA-0068', 'HP', 'Ministry of Home Affairs', 'Windows XP', 'Entire,Office2003,Symantec32bit', ' matsebulaj', '141'),
('ZAB81902N3', 'EDU-MBA-02N3', 'HP', 'Ministry of Education and Training', 'Windows 7', 'Entire,Office2007,Symantec64bit', ' nyonip', '404');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(5) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fullName`, `username`, `password`) VALUES
(1, 'Thokozani Dlamini', 'dlaminith', 'teaky'),
(2, 'Vuyani Sibandze', 'sibandzevu', 'password1'),
(5, 'Dlamini Cyril', 'dlaminicyr', 'password'),
(6, 'Dlamini Nkululeko', 'dlamininku', 'password'),
(7, 'Dlamini Mathokoza', 'dlaministh', 'password'),
(8, 'Dlamini Mlandvo', 'dlaminiml', 'password'),
(9, 'Dlamini Siphiwo ', 'dlaminisip', 'password'),
(10, 'Dlamini Siphosenkhosi', 'dlaminisiphose', 'password'),
(11, 'Dube Mfundo', 'dubem', 'password'),
(12, 'Dube Sibusiso', 'dubesi', 'password'),
(13, 'Fakudze Mfundo', 'fakudzem', 'password'),
(14, 'Hlophe Sandile', 'hlophesa', 'password'),
(15, ' Magongo Gwinsi', 'magongog', 'password'),
(16, 'Maseko Solani', 'masekoso', 'password'),
(17, 'Mavimbela Sandile', 'mavimbelasa', 'password'),
(18, 'Mdluli Mlingani', 'mdluliml', 'password'),
(19, 'Mdluli Sibusiso', 'mdlulisib', 'password'),
(20, 'Nxumalo Kuhle', 'nxumaloku', 'password'),
(21, 'Simelane Thembumusa', 'simelanek', 'password'),
(22, 'Vilakati Phiwayinkhosi', 'vilakatip', 'password'),
(23, 'Thokozani Dlamini', 'dlaminitho', 'password'),
(24, 'Vilakati Sabelo', 'vilakatis', 'password');

function formValidation() {
// Make quick references to our fields.
var sNumber = document.getElementById("sNumber ").value;
var cName = document.getElementById("cName").value;
var make = document.getElementById("make").value;
var ministry = document.getElementById("ministry").value;
var os = document.getElementById("os").value;
var software = document.getElementById("software").value;
var username = document.getElementById("username").value;
var offNumber = document.getElementById("offNumber").value;
// To check empty form fields.
if (sNumber.value.length == 0) {
document.getElementById('head').innerText = "* All fields are mandatory *"; // This segment displays the validation rule for all fields
sNumber.focus();
return false;
}
// Check each input in the order that it appears in the form.
if (textAlphanumeric(sNumber, "* For your Serial number please use use numbers and letters *")) {
if (inputAlphabet (cName,  "* For your computer name please use alphabets only *")) {
if (trueSelection(make, "* Please Choose any one option")) {
if (trueSelection(ministry, "* Please Choose any one option")) {
if (trueSelection(os, "* Please Choose any one option")) {
if (truecheckbox(software, "* Please Choose any  option")) {
if (lengthDefine(username, 4, 8)) {
if (textAlphanumeric(sNumber, "* For your office number please use use numbers and letters *")) {
return true;
}
}
}
}
}
}
}
}

return false;
}
// Function that checks whether input text includes alphabetic and numeric characters.
function textAlphanumeric(inputtext, alertMsg) {
var alphaExp = /^[0-9a-zA-Z]+$/;
if (inputtext.value.match(alphaExp)) {
return true;
} else {
document.getElementById('p1').innerText = alertMsg; 
inputtext.focus();
return false;
}
}
function inputAlphabet(inputtext, alertMsg) {
var alphaExp = /^[a-zA-Z]+$/;
if (inputtext.value.match(alphaExp)) {
return true;
} else {
document.getElementById('p2').innerText = alertMsg; 
//alert(alertMsg);
inputtext.focus();
return false;
}
}
function trueSelection(inputtext, alertMsg) {
if (inputtext.value == "Please Choose") {
document.getElementById('p3').innerText = alertMsg; 
inputtext.focus();
return false;
} else {
return true;
}
}
function trueSelection(inputtext, alertMsg) {
if (inputtext.value == "Please Choose") {
document.getElementById('p5').innerText = alertMsg; 
inputtext.focus();
return false;
} else {
return true;
}
}
function trueSelection(inputtext, alertMsg) {
if (inputtext.value == "Please Choose") {
document.getElementById('p6').innerText = alertMsg; 
return false;
} else {
return true;
}
}
// Function that checks whether the input characters are restricted according to defined by user.
function lengthDefine(inputtext, min, max) {
var uInput = inputtext.value;
if (uInput.length >= min && uInput.length <= max) {
return true;
} else {
document.getElementById('p7').innerText = "* Please enter between " + min + " and " + max + " characters *"; // This segment displays the validation rule for username
inputtext.focus();
return false;
}
}

// Function that checks whether input text includes alphabetic and numeric characters.
function textAlphanumeric(inputtext, alertMsg) {
var alphaExp = /^[0-9a-zA-Z]+$/;
if (inputtext.value.match(alphaExp)) {
return true;
} else {
document.getElementById('p8').innerText = alertMsg; 
inputtext.focus();
return false;
}
}

<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
if(isset ($_GET['user_id']))
{
$user_id= mysql_real_escape_string($_GET['user_id']);

						if (!($resultset = mysql_query($query)))
									{
										print (mysql_error());
										exit(0);
									}
?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo $user;?> - Computer Services</title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<script src="js/function.js" type="text/javascript"></script>

 <style>#left_column{
height: 490px;
}</style>
</head>
<body>
<div id="content">
<div id="header">
<h1><a href="#"><img src="images/hd_logo.jpg"></a>Computer Software Management System &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php echo " " . date("Y/m/d h:i:sa");?></h1>
<h3> Developed by: Government Computer Services &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<font color='green' >WELCOME:&emsp;</font><?php echo $user;?></h3></div>
<div id="left_column">
<div id="button">
<ul>
			<li><a href="admin.php">Dashboard</a></li>
			<li><a href="admin_user.php">User</a></li>
			<li><a href="admin_computer.php">Computer</a></li>
			<li><a href="logout.php">Logout</a></li>
			
		</ul>	
</div>
		</div>
<div id="main">
<div id="tabbed_box" class="tabbed_box">  
    <h4>Manage Users</h4> 
<hr/>	
    <div class="tabbed_area">  
      
        <ul class="tabs">  
            <li><a href="javascript:tabSwitch('tab_1', 'content_1');" id="tab_1" class="active">Update User</a></li>  
              
        </ul>  
          
        <div id="content_1" class="content">  
		<?php
		 	while($row = mysql_fetch_array($resultset, MYSQL_ASSOC))
				{
			 ?>
          <form name="myform" onsubmit="return validateForm(this);" action="admin_user.php" method="post" >
			<table width="420" height="106" border="0" >
			
			
				<input type="hidden" name="user_id" value="<?php echo $row['user_id']?>" > 
				<tr><td align="center"><input name="fullName" type="text" style="width:170px" placeholder="First Name" value="<?php  echo $row['fullName']?>" id="fullName" /></td></tr>  
				<tr><td align="center"><input name="username" type="text" style="width:170px" placeholder="Username" id="username"value="<?php echo $row['username']?>" /></td></tr>
				<tr><td align="center"><input name="password" placeholder="Password" id="password"value="<?php echo $row['password']?>"type="text" style="width:170px"/></td></tr>
				<tr><td align="left"><input name="update_btn" type="submit" size="8" value="Update"/></td></tr>
            </table>
		</form>
		<?php
		}
		?>
		</div>  
    </div>  
</div>
</div>
<div id="footer" align="Center"> Computer services @2016. Copyright All Rights Reserved</div>
</div>
</body>
</html>

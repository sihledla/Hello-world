<?php

//error_reporting (E_ALL ^ E_NOTICE ^ E_WARNING);

$servername = 'localhost';
$username = 'root';
$password = '';
// Create connection
$conn = mysql_connect($servername, $username, $password);
// Check connection
if (!$conn)
{
die("Connection failed: " . mysql_error());
}
//Select Database
mysql_select_db('computer_services') or die ('Unable to find database');
//echo "Connected successfully";


?>
<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$fname=$_SESSION['fullName'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
?>
<script>
function validateForm()
{
var x=document.forms["form1"]["username"].value;
var y=document.forms["form1"]["oldpass"].value;
var z=document.forms["form1"]["newpass"].value;
var a=document.forms["form1"]["confpass"].value;
if (x==null || x=="")
  {
  alert("Login username must be filled out");
  return false;
  }
  if (y==null || y=="")
  {
  alert("Old password must be filled out");
  return false;
  }
  if (z==null || z=="")
  {
  alert("New password must be filled out");
  return false;
  }
   if (a==null || a=="")
  {
  alert("Password must be confirmed");
  return false;
  }
}
</script>
<?php

if(isset($_POST["button"]))

{ 
mysql_query("UPDATE users SET password='$_POST[newpass]' WHERE username = '$_POST[username]' AND password='$_POST[oldpass]'");
	if(mysql_affected_rows() == 1)
	{
	$ctrow = "Password updated successfully...";
	}
	else
	{
	$ctrow = "Failed to update Password";
	}
}

?>
<!DOCTYPE html>
   <html>
<head>
<title><?php echo $user;?> - Computer Services </title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" type="text/css" href="style/dashboard_styles.css"  media="screen" />
<script src="js/function.js" type="text/javascript"></script>
<style>
#left_column{
height: 505px;
}
</style>
</head>
<body>
<div id="content">
<div id="header">
<h1><a href="#"><img src="images/hd_logo.jpg"></a>Computer Software Management System
&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php echo " " . date("Y/m/d h:i:sa");?></h1>
<h3> Developed by: Government Computer Services &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<font color='green' >WELCOME:&emsp;</font><?php echo $fname;?></h3></div>
   
	<div id="left_column">
<div id="button">
<ul>
			<li><a href="user.php">Dashboard</a></li>
			<li><a href="computer.php">Add Computer</a></li>
			<li><a href="view.php">view Computers</a></li>
			<li><a href="changepas.php"> Set New Password</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>	
</div>
</div>		
			
                
        	<h2>Change Login password</h2>

        	<form id="form1" name="form1" method="post" action=""onsubmit="return validateForm()">
     
        	  <table width="561" height="292" border="4">
			  
			  
			  
        	    <tr>
        	      <th colspan="2" scope="row">&nbsp;
			
				   
					<font color="#FFF"><?php echo $ctrow?></font>
					
				  			  
		</th>
       	        </tr>
        	    <tr>
        	      <th width="341" height="45">LOGIN USERNAME</th>
        	      <td width="210"><input name="username" type="text" id="username" size="35"  value="<?php echo $_SESSION["username"]; ?>"/>
                  </td>
      	      </tr>
        	    <tr>
        	      <th height="49">OLD PASSWORD</th>
        	      <td><input name="oldpass" type="password" id="oldpass" size="35" /></td>
      	      </tr>
        	    <tr>
        	      <th height="44" >NEW PASSWORD</th>
        	      <td><input name="newpass" type="password" id="newpass" size="35" /></td>
      	      </tr>
        	    <tr>
        	      <th height="43">CONFIRM PASSWORD</th>
        	      <td><input name="confpass" type="password" id="confpass" size="35" /></td>
      	      </tr>
        	   
        	    <tr>
        	      <th scope="row">&nbsp;</th>
        	      <td><input type="submit" name="button" id="button" value="CHANGE PASSWORD" /></td>
      	      </tr>
      	    </table>
        	  <p>&nbsp;</p>
          </form>
        	<p>&nbsp;</p>
       	  </div>
		  <div id="footer" align="Center">Computer services @2016. Copyright All Rights Reserved</div>
        </div><!-- end of content -->
            </body>
			</html>
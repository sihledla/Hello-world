<?php
session_start();
unset($_SESSION['staff_id']);

unset($_SESSION['fullName']);
unset($_SESSION['username']);
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
?>

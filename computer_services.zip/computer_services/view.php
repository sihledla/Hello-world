<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$id=$_SESSION['user_id'];
$fname=$_SESSION['fullName'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo $user;?> -Computer services</title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" href="style/table.css" type="text/css" media="screen" /> 
<script src="js/function1.js" type="text/javascript"></script>
   <style>#left-column {height: 477px;}
 #main {height: 2000px;}
</style>
</head>
<body>
<div id="content">
<div id="header">
<h1><a href="#"><img src="images/hd_logo.jpg"></a> Computer Software Management System &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php echo " " . date("Y/m/d h:i:sa");?></h1>
<h3> Developed by: Government Computer Services &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<font color='green' >WELCOME:&emsp;</font><?php echo $fname;?></h3></div>
<div id="left_column">
<div id="button">
		<ul>
			<li><a href="user.php">Dashboard</a></li>
			<li><a href="computer.php">Add Computer </a></li>
			<li><a href="view.php"> View Computers</a></li>
			<li><a href="changepas.php"> Set New Password</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>	
</div>
</div>
<!--SEARCH FORM START-->
<div class="search">
						<form action="" method="post" name="search_refresh" align="left">
							<br/>
									&emsp;<input type="submit" name="search_btn" value="Search" id="submit_buttons">&emsp;&emsp;
									<input type="text" name="search_txt" size="25" maxlength="90" placeholder="search" >&emsp;&emsp;
									<input type="submit" name="load_btn" value="Refresh" id="submit_buttons">&emsp;&emsp;
					
							<label><b><font color="#00008B" size="4" > Total Of Computers: </font></b></label>
							<?php 												//counting total
							$result = mysql_query("SELECT * FROM computer"); 
                             $num_rows = mysql_num_rows($result); 
							echo $num_rows; ?>
						</form>
					</div>
					<!--SEARCH FORM END-->
  <div id="main">     
   
<div id="tabbed_box" class="tabbed_box">  
    <h4>View  Computers</h4> 
<hr/>	
  <div class="tabbed_area">  
      
        <ul class="tabs">  
            <li><a href="javascript:tabSwitch('tab_1', 'content_1');" id="tab_1" class="active">View Computer</a></li>  
              
        </ul>  
          
        <div id="content_1" class="content">  
  
      
<?php 
		
/* 
		View
        Displays all data from 'Computer' table
		*/

        // connect to the database
        include_once('connect_db.php');

        // get results from database
		
        $result = mysql_query("SELECT * FROM computer") 
                or die(mysql_error());
				
					    
        // display data in table
        
        echo "<table border='1' cellpadding='3' align=''>";
        echo "<tr> <th>SNumber</th><th>ComputerName </th><th>Make </th><th>Ministry </th><th>OS</th><th>Software</th><th>Username </th><th>OffNumber </th><th>Update </th></tr>";
?>
<?php
		if(isset($_POST['search_btn']))
						{	
								Search();
						}
						else
							if(isset($_POST['load_btn']))
							{
								LoadTable();
							}
							else
								{
									LoadTable();
								}
	
	
        // close table>
        echo "</table>";
	?>

<tr><td><p> <a href="#top">Click here to scroll Up!!!</a><p></td></tr>
</div>

</div>
</div>
</div>

</div>
</body>
</html>

<?php
			function LoadTable()
	{
		$query = ("SELECT * FROM computer");
								if (!($resultset = mysql_query($query)))
									{
										print (mysql_error());
										exit(0);
									}
								while ($row = mysql_fetch_array($resultset, MYSQL_ASSOC))
									{
										print '<tr>';	
										echo '<td>' . $row['sNumber'] . '</td>';
                                        echo '<td>' . $row['cName'] . '</td>';
				                        echo '<td>' . $row['make'] . '</td>';
				                        echo '<td>' . $row['ministry'] . '</td>';
				                        echo '<td>' . $row['os'] . '</td>';
				                       echo '<td>' . $row['software'] . '</td>';
				                       echo '<td>' . $row['username'] . '</td>';
				                        echo '<td>' . $row['offNumber'] . '</td>';
										
										?>
				<td><a href="edit_computer.php?sNumber=<?php echo $row['sNumber']?>"><img src="images/update-icon.png" width="35" height="35" border="0" /></a></td>
				
				<?php
				print '</tr>';
				}
	
	}

	
	function Search()
	{
		$search=$_POST['search_txt'];
							
		$query = ("SELECT * FROM computer WHERE sNumber LIKE '%$search%'  OR "."cName LIKE '%$search%' OR ".
				"make LIKE '%$search%' OR "."ministry LIKE '%$search%' OR "."os LIKE '%$search%' OR "."software LIKE '%$search%' OR ".
				"username LIKE '%$search%' OR "."offNumber LIKE '%$search%'								
				");	
        // loop through results of database query, displaying them in the table
		if (!($resultset = mysql_query($query)))
			{
				print (mysql_error());
				exit(0);
			}
        while($row = mysql_fetch_array( $resultset, MYSQL_ASSOC )) {
                
                // echo out the contents of each row into a table
                echo "<tr>";
                
                echo '<td>' . $row['sNumber'] . '</td>';
                echo '<td>' . $row['cName'] . '</td>';
				echo '<td>' . $row['make'] . '</td>';
				echo '<td>' . $row['ministry'] . '</td>';
				echo '<td>' . $row['os'] . '</td>';
				echo '<td>' . $row['software'] . '</td>';
				echo '<td>' . $row['username'] . '</td>';
				echo '<td>' . $row['offNumber'] . '</td>';
				?>
				<td><a href="edit_computer.php?sNumber=<?php echo $row['sNumber']?>"><img src="images/update-icon.png" width="35" height="35" border="0" /></a></td>
				
				<?php
				  echo "</tr>";

	} }
	

// Display the results 


?> 
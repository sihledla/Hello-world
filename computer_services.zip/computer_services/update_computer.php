<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
if(isset ($_GET['sNumber']))
{
$sNumber= mysql_real_escape_string($_GET['sNumber']);
}
?>


<?php
	
	$query = ("SELECT * FROM computer WHERE sNumber='$sNumber'");
				
						if (!($resultset = mysql_query($query)))
									{
										print (mysql_error());
										exit(0);
									}
?>
<!DOCTYPE html>
<html>
<head>
<title><?php $user;?> computer software</title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<script src="js/function.js" type="text/javascript"></script>
 <style>#left-column {height: 477px;}
 #main {height: 477px;}</style>
</head>
<body>
<div id="content">
<div id="header">
<h1><a href="#"><img src="images/hd_logo.jpg"></a> Computer Software Management System &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php echo " " . date("Y/m/d h:i:sa");?></h1>
<h3> Developed by: Government Computer Services &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<font color='green' >WELCOME:&emsp;</font><?php echo $user;?></h3></div>
<div id="left_column">
<div id="button">
<ul>
			<li><a href="admin.php">Dashboard</a></li>
			<li><a href="admin_user.php">User</a></li>
			<li><a href="admin_computer.php">Computer</a></li>
			<li><a href="logout.php">Logout</a></li>
			
		</ul>	
</div>
		</div>
<div id="main">
<div id="tabbed_box" class="tabbed_box">  
    <h4>Manage Computer</h4> 
<hr/>	
    <div class="tabbed_area">  
      
        <ul class="tabs">  
            <li><a href="javascript:tabSwitch('tab_1', 'content_1');" id="tab_1" class="active">Update Computer</a></li>  
              
        </ul>  
          
        <div id="content_1" class="content">  
		<?php
		 	while($row = mysql_fetch_array($resultset, MYSQL_ASSOC))
				{
			 ?>
       <form name="myform" onsubmit="return validateForm(this);" action="admin_computer.php" method="post" >
			<table width="420" height="106" border="0" >	
				<tr><td align="left"><label for="sNumber" class="sNumber" data-icon="s" ><b><font color="#00008B" size="4" required="required"> SERIAL NUMBER: <b/></font></label><input name="sNumber" type="text" style="width:170px" placeholder="Serial Number" value="<?php  echo $row['sNumber']?>" id="fullName" /></td></tr>
				<tr><td align="left"><label for="cName" class="cName" data-icon="s" ><b><font color="#00008B" size="4" required="required"> COMPUTER NAME: <b/></font></label><input name="cName" type="text" style="width:170px" placeholder="Computer Name" id="cName" value="<?php  echo $row['cName']?>" id="cName"  /></td></tr>
				<tr><td align="left"><label for="make" class="make" data-icon="s" ><b><font color="#00008B" size="4" required="required"> MODEL: <b/></font></label>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<select id ="make" name="make" style="width:170px"  id="staff_id"  value="<?php  echo $row['make']?>""<?php  echo $row['make']?>"/>
				                      <option value="">--Select Model--</option>
									  
										  <option <?php if($row['make']=="ACER"){echo "selected";}?>>ACER</option>
										  <option <?php if($row['make']=="HP"){echo "selected";}?>>HP</option>
										  <option <?php if($row['make']=="TOSHIBA"){echo "selected";}?>>TOSHIBA</option>
										  <option <?php if($row['make']=="LENOVO"){echo "selected";}?>>LENOVO</option>
										  <option <?php if($row['make']=="DELL"){echo "selected";}?>>DELL</option>
										  <option <?php if($row['make']=="OTHER"){echo "selected";}?>>OTHER</option>
										  </select></td></tr>  
				<tr><td align="left"><label for="ministry" class="ministry" data-icon="s" ><b><font color="#00008B" size="4" required="required"> MINISTRY: <b/></font></label>&emsp;&emsp;&emsp;&emsp;&emsp;<select id ="make" name="ministry" style="width:170px"  id="ministry"  value="<?php  echo $row['ministry']?>""<?php  echo $row['ministry']?>"/>	
										   <option value=""  >--Select Ministry-- </option>
										 
	      <option <?php if($row['ministry']=="Prime Minister's Office"){echo "selected";}?>>Prime Minister's Office</option>
		  <option <?php if($row['ministry']=="Deputy Prime Minister's Office"){echo "selected";}?>>Deputy Prime Minister's Office</option>
			<option <?php if($row['ministry']=="Ministry of Agriculture"){echo "selected";}?>>Ministry of Agriculture</option>
		<option <?php if($row['ministry']=="Ministry of Commerce, Industry and Trade"){echo "selected";}?>>Ministry of Commerce, Industry and Trade</option>
	 <option <?php if($row['ministry']=="Ministry of Economic Planning & Development"){echo "selected";}?>>Ministry of Economic Planning & Development</option>
			  <option <?php if($row['ministry']=="Ministry of Education and Training"){echo "selected";}?>>Ministry of Education and Training</option>
				<option <?php if($row['ministry']=="Ministry of Finance"){echo "selected";}?>>Ministry of Finance</option>
			<option <?php if($row['ministry']=="Ministry of Foreign Affairs & International Cooperation"){echo "selected";}?>>Ministry of Foreign Affairs & International Cooperation</option>
						<option <?php if($row['ministry']=="Ministry of Health"){echo "selected";}?>>Ministry of Health</option>
							 <option <?php if($row['ministry']=="Ministry of Home Affairs"){echo "selected";}?>>Ministry of Home Affairs</option>
		 <option <?php if($row['ministry']=="Ministry of Housing and Urban Development"){echo "selected";}?>>Ministry of Housing and Urban Development</option>
 <option <?php if($row['ministry']=="Ministry of Information, Communications and Technology"){echo "selected";}?>> Ministry of Information, Communications and Technology</option>
		<option <?php if($row['ministry']=="Ministry of Justice"){echo "selected";}?>>Ministry of Justice</option>
		<option <?php if($row['ministry']=="Ministry of Labour & Social Security"){echo "selected";}?>>Minstry of Labour & Social Security</option>
	<option <?php if($row['ministry']=="Ministry of Natural Resources and Energy "){echo "selected";}?>>Ministry of Natural Resources and Energy </option>
									<option <?php if($row['ministry']=="Royal Swaziland Police"){echo "selected";}?>>Royal Swaziland Police</option>
			 <option <?php if($row['ministry']=="Ministry of Public  Works and Transport"){echo "selected";}?>>Ministry of Public  Works and Transport</option>
		<option <?php if($row['ministry']=="Ministry of Sports, Culture & Youth Affairs"){echo "selected";}?>>Ministry of Sports, Culture & Youth Affairs</option>
					<option <?php if($row['ministry']=="Ministry of Tinkhundla"){echo "selected";}?>>Ministry of Tinkhundla</option>
						<option <?php if($row['ministry']=="Ministry of Tourism & Environmental Affairs<"){echo "selected";}?>>Ministry of Tourism & Environmental Affairs</option>
										  <option <?php if($row['ministry']=="Parliament of Swaziland"){echo "selected";}?>>Parliament of Swaziland</option>
										  <option <?php if($row['ministry']=="Correctional Services"){echo "selected";}?>>Correctional Services</option>
										  <option <?php if($row['ministry']=="Ministry of Defence"){echo "selected";}?>> Ministry of Defence</option>
										  
									</select></td></tr>				 				
				<tr><td align="left"><label for="os" class="os" data-icon="s" ><b><font color="#00008B" size="4"> OPERATING SYSTEM: <b/></font></label><select id ="os" name="os" style="width:170px"  id="os"  required="required" value="<?php  echo $row['os']?>""<?php  echo $row['os']?>"/>	
				                            <option value=""> --Select Windows--</option>
										  <option <?php if($row['os']=="Windows XP"){echo "selected";}?>>Windows XP</option>
										  <option <?php if($row['os']=="Windows 7"){echo "selected";}?>>Windows 7</option>
										  <option <?php if($row['os']=="Windows 8"){echo "selected";}?>>Windows 8</option>
										  <option <?php if($row['os']=="Windows 8.1"){echo "selected";}?>>Windows 8.1</option>
										  <option <?php if($row['os']=="Windows 10"){echo "selected";}?>>Windows 10</option>
									</select></td></tr>
	<tr><td align="left"><label for="software" class="software" data-icon="s" ><b><font color="#00008B" size="4" required="required"> SOFTWARE: <b/></font></label></br>
	                <?php 
					$chkbox=$row['software'];
					$software=explode(",",$chkbox);
					
					?>
	                       <input <?php if(in_array("Entire",$software)){echo "checked";}?> type="checkbox" name="software[]" value="Entire"  />Entire
						<input <?php if(in_array("Office 2003",$software)){echo "checked";}?> type="checkbox" name="software[]" value="Office2003" /> Office 2003
					<input <?php if(in_array("office 2007",$software)){echo "checked";}?> type="checkbox" name="software[]" value="Office2007"  /> Office 2007
				  <input <?php if(in_array("office 2010",$software)){echo "checked";}?> type="checkbox" name="software[]" value="Office2010"  /> Office 2010
					<input <?php if(in_array("office 2013",$software)){echo "checked";}?> type="checkbox" name="software[]" value="Office2013"  /> Office 2013 
				<input <?php if(in_array("Symantec 64bit",$software)){echo "checked";}?> type="checkbox" name="software[]" value="Symantec64bit"  /> Symantec 64bit
				<input <?php if(in_array("Symantec 32bit",$software)){echo "checked";}?> type="checkbox" name="software[]" value="Symantec32bit"  /> Symantec 32bit
									
				 </td></tr>
				<tr><td align="left"><label for="username" class="username data-icon="s" ><b><font color="#00008B" size="4"> COMPUTER NAME: <b/></font></label><input name="username" type="text" style="width:170px" placeholder="Username" id="username"value=" <?php  echo $row['username']?>" id="username"/></td></tr>
				<tr><td align="left"><label for="offNumber" class="offNumber" data-icon="s" ><b><font color="#00008B" size="4" required="required"> OFFICE NUMBER <b/></font></label><input name="offNumber" placeholder="Office Number" id="offNumber"value="<?php  echo $row['offNumber']?>" id="offNumber" type="text" style="width:170px"/></td></tr>
				<tr><td align="center"><input name="update_btn" type="submit" value="Update"/></td></tr>
            </table>
		</form>
		<?php
		}
		?>
		</div>  
    </div>  
</div>
</div>
<div id="footer" align="Center"> Computer services @2016. Copyright All Rights Reserved</div>
</div>
</body>
</html>

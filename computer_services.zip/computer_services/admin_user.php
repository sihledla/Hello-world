<?php
session_start();
include_once('connect_db.php');

if(isset($_SESSION['username'])){
$id=$_SESSION['admin_id'];
$username=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}

?>
<?php
		if(isset($_POST['submit']))
			{
				$username = $_POST['username'];
				$query = ("SELECT * FROM users where username='$username'");
						if (!($resultset = mysql_query($query)))
									{
										print (mysql_error());
										exit(0);
									}
								else
									if ($row = mysql_fetch_array($resultset, MYSQL_ASSOC))
										{
											echo "<script>
													alert('Error!! Username already exists');
													window.location.href='admin_user.php';
												</script>";
										}
										else
										{
											insert();
										}
			}
		else
			if(isset($_POST['update_btn']))
				{
					update();			
				}
			else
				if(isset($_POST['submit']))
					{
						delete();
					}
	

?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo $username;?> - computer software </title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" href="style/table.css" type="text/css" media="screen" /> 
<script src="js/function.js" type="text/javascript"></script>
<script src="js/validation_script.js" type="text/javascript"></script>

 <style>
<style>#left-column {height:1500px}
 #main {height:2000px}</style>
 </style>
</head>
<body onload='validateForm()'>
<div id="content">
<div id="header">
<h1><a href="#"><img src="images/hd_logo.jpg"></a> Computer Software Management System&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php echo " " . date("Y/m/d h:i:sa");?></h1>
<h3> Developed by: Government Computer Services &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<font color='green' >WELCOME:&emsp;</font><?php echo $username;?></h3></div>
<div id="left_column">
<div id="button">
<ul>
			<li><a href="admin.php">Dashboard</a></li>
			<li><a href="admin_user.php">User</a></li>
			<li><a href="admin_computer.php">Computer Details</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>	
</div>
		</div>
<div id="main">
<div id="tabbed_box" class="tabbed_box">  
    <h4>Manage User</h4> 
<hr/>	
    <div class="tabbed_area">  
	
      
        <ul class="tabs">  
            <li><a href="javascript:tabSwitch('tab_1', 'content_1');" id="tab_1" class="active">View User</a></li>  
            <li><a href="javascript:tabSwitch('tab_2', 'content_2');" id="tab_2">Add User</a></li>  
              
        </ul>  
          
        <div id="content_1" class="content">  
		<?php
			  
		/* 
		View
        Displays all data from 'users' table
		*/

        // connect to the database
        include_once('connect_db.php');

        // get results from database
		
        $result = mysql_query("SELECT * FROM users ") 
                or die(mysql_error());
				
					    
        // display data in table
        
        echo "<table border='1' cellpadding='5' align=''>";
        echo "<tr> <th>ID</th><th>Fullname </th>  <th>Username </th><th>Update </th><th>Delete</th></tr>";

        // loop through results of database query, displaying them in the table
        while($row = mysql_fetch_array( $result )) {
   // echo   " <form name='form1' onsubmit='return validateForm(validation_script.js);' action='admin_user.php' method='post' > "   ;    
                // echo out the contents of each row into a table
                echo "<tr>";
                
                echo '<td>' . $row['user_id'] . '</td>';
                echo '<td>' . $row['fullName'] . '</td>';
				echo '<td>' . $row['username'] . '</td>';
				?><form action="update_user.php" method="post" name="mm">
				<input type="hidden" name="user_id" value="<?php echo $row['user_id']?>" > 
				</form>
				<td><a href="update_user.php?user_id=<?php echo $row['user_id']?>"><img src="images/update-icon.png" width="35" height="35" border="0" /></a></td>
				<td><a href="delete_user.php?user_id=<?php echo $row['user_id']?>" onclick="return confirm('Are you sure you wish to delete this Record?');"><img src="images/delete-icon.png" width="35" height="35" border="0" /></a></td>
		
				<?php
		 } 
		
        // close table>
        echo "</table>";                                
?> 
<tr><td><p> <a href="#top">Click here to scroll Up!!!</a><p></td></tr>
        </div>  
        <div id="content_2" class="content">  
		           <!--User-->
		
		<form name="form"  onsubmit="return formValidation()" action="admin_user.php" method="post" >
			<table width="300" height="106" border="0" >	
				<tr><td align="center"><input name="fullName" type="text" style="width:170px" placeholder="First Name"   id="fullName" /></td></tr>		
				<tr><td align="center"><input name="username" type="text" style="width:170px" placeholder="Username" required="required" id="username" /></td></tr>
				<tr><td align="center"><input name="password" type="password" style="width:170px" placeholder="Password" required="required" id="password"/></td></tr>
				<tr><td align="right"><input name="submit" type="submit" value="Submit" ></td></tr>
				
            </table>
		</form>
        </div>   
        
      
    </div>  
  
</div>
 
</div>
<div id="footer" align="Center">Computer services @2016. Copyright All Rights Reserved</div>
</div>
</body>
</html>

<?php

function insert()
	{
$fullName=$_POST['fullName'];
if (!preg_match("/^[a-zA-Z ]*$/",$fullName))
  {
  $nameErr = "Only letters and white space allowed";
  }
$username=$_POST['username'];
$password=$_POST['password'];

$sql1=mysql_query("SELECT * FROM users WHERE username='$username'")or die(mysql_error());
 $result=mysql_fetch_array($sql1);
 if($result>0){
$message="<font color=blue>sorry the username entered already exists</font>";
 }else{
$sql=mysql_query("INSERT INTO users VALUES(Null,'$fullName','$username','$password')");
if($sql>0) {header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/admin_user.php");
}else{
$message1="<font color=red>Registration Failed, Try again</font>";
}
}}

function update()
{
	
		$user_id=$_POST['user_id'];	
		$fullName=$_POST['fullName'];
		$username=$_POST['username'];
		$password=$_POST['password'];	

		$sql_update= mysql_query("UPDATE users SET
                    fullName='$fullName',
					username='$username',
					password='$password'
					WHERE user_id='$user_id'");
		echo "<script>
				alert('Update Successful');
				window.location.href='admin_user.php';
			</script>";
}
?>

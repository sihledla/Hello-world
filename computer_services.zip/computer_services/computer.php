<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$id=$_SESSION['user_id'];
$fname=$_SESSION['fullName'];
$username=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
?>


<?php
		if(isset($_POST['submit']))
			{
				$sNumber = $_POST['sNumber'];
				$query = ("SELECT * FROM computer where sNumber='$sNumber'");
						if (!($resultset = mysql_query($query)))
									{
										print (mysql_error());
										exit(0);
									}
								else
									if ($row = mysql_fetch_array($resultset, MYSQL_ASSOC))
										{
											echo "<script>
													alert('Error!!Serial Number already exists');
													window.location.href='computer.php';
												</script>";
										}
										else
										{
											insert();
										}
			}
		else
			if(isset($_POST['update_btn']))
				{
					update();			
				}
			else
				if(isset($_POST['submit']))
					{
						delete();
					}
	

?>


<!DOCTYPE html>
<html>
<head>
<title><?php echo $username;?> - computer software </title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" href="style/table.css" type="text/css" media="screen" /> 
<script src="js/function.js" type="text/javascript"></script>
<script src="js/validation_script.js" type="text/javascript"></script>

 <style>
#left_column{
height: 500px;
}
 </style>
 
</head>
<body onload='document.form1.sNumber.focus()'>
<div id="content">
<div id="header">
<h1><a href="#"><img src="images/hd_logo.jpg"></a> Computer Software Management System &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php echo " " . date("Y/m/d h:i:sa");?></h1>
<h3> Developed by: Government Computer Services &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<font color='green' >WELCOME:&emsp;</font><?php echo $fname;?></h3></div>
<div id="left_column">
<div id="button">
<ul>
			<li><a href="user.php">Dashboard</a></li>
			<li><a href="computer.php">Add Computer </a></li>
			<li><a href="view.php"> View Computers</a></li>
			<li><a href="changepas.php"> Set New Password</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>	
</div>
		</div>

		</br>
<div id="main">
<div id="tabbed_box" class="tabbed_box">  
    <h4>Computer</h4> 
<hr/>	
    <div class="tabbed_area">  
      
        <ul class="tabs">  
            <li><a href="javascript:tabSwitch('tab_1', 'content_1');" id="tab_1" class="active">Add Computer</a></li>  
              
        </ul>  
          
        <div id="content_1" class="content"> 
		<form name="form1"  onsubmit="return validateForm(this);" action="" method="post" >
			<table width="" height="" border="0" >	
				<tr><td align="left"> <label for="sNumber" class="sNumber" data-icon="s" ><b><font color="#00008B" size="4"> SERIAL NUMBER: <b/></font></label><input name="sNumber" type="text" style="width:170px" placeholder="Serial Number"   id="sNumber" /><p id="p1"></p></td></tr>		
				<tr><td align="left"> <label for="cName"  ><b><font color="#00008B" size="4"> COMPUTER NAME: <b/></font></label><input name="cName" type="text" style="width:170px" placeholder="e.g CS-MBA-34R4"  id="cname" /><p id="p2"></p></td></tr>
				<tr><td align="left"><label for="cName"  ><b><font color="#00008B" size="4" required="required"> MODEL:<b/></font></label> <select id ="make" name="make" type="combobox">
									     <option value="">--select model--</option>
										  <option value="ACER">Acer</option>
										  <option value="HP">HP</option>
										  <option value="TOBISHA">Toshiba</option>
										  <option value="LENOVO">Lenovo</option>
										  <option value="DELL">Dell</option>
										  <option value="OTHER">OTHER</option>
										  
										 </select><p id="p3"></p></td></tr>
			    <tr><td align="left"><label for="cName"  ><b><font color="#00008B" size="4" required="required"> Ministry:<b/></font></label> <select id ="ministry" name="ministry">
									      
										  
										   <option value=""  >--select ministry--</option>
										   <option value="Prime Minister's Office">Prime Minister's Office</option>
										   <option value="Deputy Prime Minister’s Office">Deputy Prime Minister's Office</option>
										   <option value="Ministry of Agriculture">Ministry of Agriculture</option>
										   <option value="Ministry of Commerce, Industry and Trade">Ministry of Commerce, Industry and Trade</option>
										   <option value="Ministry of Economic Planning & Development">Ministry of Economic Planning & Development</option>
										   <option value="Minstry of Education and Training">Ministry Of Education and Training</option>
										   <option value="Minstry of Finance">Ministry of Finance</option>
										   <option value="Ministry of Foreign Affairs & International Cooperation">Ministry of Foreign Affairs & International Cooperation</option>
										   <option value="Ministry of Health">Ministry of Health</option>
										   <option value="Minstry Of Home Affairs">Ministry Of Home Affairs</option>
										  <option value="Ministry of Housing and Urban Development">Ministry of Housing and Urban Development</option>
										  <option value="Ministry of Information, Communications and Technology"> Ministry of Information, Communications and Technology</option>
										  <option value="Minstry Of Justice">Ministry Of Justice</option>
										  <option value="Minstry Of Labour & Social Security">Minstry of Labour & Social Security</option>
										  <option value="Minstry of Natural Resources and Energy">Ministry of Natural Resources and Energy </option>
										  <option value="Royal Swaziland Police">Royal Swaziland Police</option>
										  <option value="Ministry of Public  Works and Transport">Ministry of Public  Works and Transport</option>
										  <option value="Ministry of Sports, Culture & Youth Affairs">Ministry of Sports, Culture & Youth Affairs</option>
										  <option value="Ministry of Tinkhundla">Ministry of Tinkhundla</option>
										  <option value="Ministry of Tourism & Environmental Affairs">Ministry of Tourism & Environmental Affairs</option>
										  <option value="Parliament of Swaziland">Parliament of Swaziland</option>
										  <option value="Correctional Services">Correctional Services</option>
										  <option value="Ministry of Defence">Ministry of Defence</option>
										  
									</select><p id="p4"></p></td></tr>				 
				<tr><td align="left"> <label for="os"  ><b><font color="#00008B" size="4" required="required"> WINDOWS:<b/></font></label></label><select id ="os" name="os">
									      
										  <option value="">--select Windows--</option>
										  <option value="WindowsXP">Windows XP</option>
										  <option value="Windows7">Windows 7</option>
										  <option value="Windows8">Windows 8</option>
										  <option value="Windows8.1">Windows 8.1</option>
										  <option value="Windows10">Windows 10</option>
									</select><p id="p5"></p></td></tr>
				<tr><td align="left"><label for="cName"  ><b><font color="#00008B" size="4" required="required"> SOFTWARE:<b/></font></label>
			</br>	                <input type="checkbox" name="software[]" value="Entire"  />Entire
									<input type="checkbox" name="software[]" value="Office2003" /> Office 2003
									<input type="checkbox" name="software[]" value="Office2007"  /> Office 2007
									<input type="checkbox" name="software[]" value="Office2010"  /> Office 2010
									<input type="checkbox" name="software[]" value="Office2013"  /> Office 2013 
									<input type="checkbox" name="software[]" value="Symantec64bit"  /> Symantec 64bit
									<input type="checkbox" name="software[]" value="Symantec32bit"  /> Symantec 32bit
									<p id="p6"></p>
										  
				<tr><td align="left"><label for="username"  ><b><font color="#00008B" size="4">SITE USERNAME: <b/></font></label><input name="username" type="text" style="width:170px" placeholder="UserName"  id="username"/><p id="p7"></p></td></tr>
				<tr><td align="left"><label for="offNumber"  ><b><font color="#00008B" size="4">OFFICE NUMBER: <b/></font></label><input name="offNumber" type="text" style="width:170px" placeholder="Office Number" id="offNumber"/><p id="p8"></p></td></tr>
				<tr><td align="right"><input size="5" name="submit" type="submit" value="Submit" onclick="alphanumeric(document.form1.sNumber)"/></br></td></tr>
				
            </table>
		</form>
   </div>     
 </div>
    
</div>
<div id="footer" align="Center">Computer services @2016. Copyright All Rights Reserved</div>
</div>
</body>
</html>


<?php
function insert()
	{
$sNumber=$_POST['sNumber'];
if (!preg_match("/^[a-zA-Z 0-9]*$/",$sNumber))
  {
  $nameErr = "Only letters and numbers allowed";
  }
$cName=$_POST['cName'];
if (!preg_match("/^[a-zA-Z ]*$/",$cName))
  {
  $nameErr = "Only letters and hyphen allowed";
  }
$make=$_POST['make'];
$ministry=$_POST['ministry'];
$os=$_POST['os'];
$software=implode(',', $_POST['software']);
$username=$_POST['username'];
$offNumber=$_POST['offNumber'];
if($_POST['sNumber']=="" || $_POST['cName']=="" || $_POST['make']=="" || $_POST['ministry']==""    || $_POST['username']=="" || $_POST['offNumber']=="")
	{
	echo "<script>
				alert('Please fill up all fields!!!');
				window.location.href='computer.php';
			</script>";
	}
	else{

$sql1=mysql_query("SELECT * FROM computer WHERE sNumber='$sNumber'")or die(mysql_error());
 $result=mysql_fetch_array($sql1);
 if($result>0){
$message="<font color=blue>sorry the Serial Number entered already exists</font>";
 }else{
$sql=mysql_query("INSERT INTO computer VALUES('$sNumber','$cName','$make','$ministry','$os','$software','$username','$offNumber')");
if($sql>0) {header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/computer.php");
}else{
$message1="<font color=red>Registration Failed, Try again</font>";
}
	}}}
function update()
{
	
$sNumber=$_POST['sNumber'];
$cName=$_POST['cName'];
$make=$_POST['make'];
$ministry=$_POST['ministry'];
$os=$_POST['os'];
$software=implode(',', $_POST['software']);
$username=$_POST['username'];
$offNumber=$_POST['offNumber'];
if($_POST['sNumber']=="" || $_POST['cName']=="" || $_POST['make']=="" || $_POST['ministry']==""    || $_POST['username']=="" || $_POST['offNumber']=="")
	{
	echo "<script>
				alert('Please fill up all fields!!!');
				window.location.href='view.php';
			</script>";
	}
	else{
 

$sql_update= mysql_query("UPDATE computer SET sNumber='$sNumber', 
                          cName='$cName', 
						  make='$make',
						  ministry='$ministry',
						  os='$os',
						  software='$software',
						  username='$username', 
						  offNumber='$offNumber' 
						  WHERE sNumber='$sNumber'");
						  
						  
echo "<script>
				alert('Update Successful');
				window.location.href='view.php';
			</script>";
	}
}
?>


<?php
			function LoadTable()
	{
		$query = ("SELECT * FROM computer");
								if (!($resultset = mysql_query($query)))
									{
										print (mysql_error());
										exit(0);
									}
								while ($row = mysql_fetch_array($resultset, MYSQL_ASSOC))
									{
										print '<tr>';	
										echo '<td>' . $row['sNumber'] . '</td>';
                                        echo '<td>' . $row['cName'] . '</td>';
				                        echo '<td>' . $row['make'] . '</td>';
				                        echo '<td>' . $row['ministry'] . '</td>';
				                        echo '<td>' . $row['os'] . '</td>';
				                       echo '<td>' . $row['software'] . '</td>';
				                       echo '<td>' . $row['username'] . '</td>';
				                        echo '<td>' . $row['offNumber'] . '</td>';
										echo '<td>' . $row['Total'] . '</td>';
										
										?>
				<td><a href="update_computer.php?sNumber=<?php echo $row['sNumber']?>"><img src="images/update-icon.png" width="35" height="35" border="0" /></a></td>
				<td><a href="delete_computer.php?sNumber=<?php echo $row['sNumber']?>" onclick="return confirm('Are you sure you wish to delete this Record?');"><img src="images/delete-icon.png" width="35" height="35" border="0" /></a></td>
				<?php
				print '</tr>';
				}
	
	}

	
	function Search()
	{
		$search=$_POST['search_txt'];
							
		$query = ("SELECT sNumber, cName,make,ministry,os,software,username,offNumber, count(sNumber) AS 'Total'
					FROM computer 
					WHERE sNumber LIKE '%$search%'  OR 
							"."cName LIKE '%$search%' OR ".
							"make LIKE '%$search%' OR "."ministry LIKE '%$search%' OR "."os LIKE '%$search%' OR "."software LIKE '%$search%' OR ".
				"username LIKE '%$search%' OR "."offNumber LIKE '%$search%'								
				");	
        // loop through results of database query, displaying them in the table
		if (!($resultset = mysql_query($query)))
			{
				print (mysql_error());
				exit(0);
			}
        while($row = mysql_fetch_array( $resultset, MYSQL_ASSOC )) {
                
                // echo out the contents of each row into a table
                echo "<tr>";
                
                echo '<td>' . $row['sNumber'] . '</td>';
                echo '<td>' . $row['cName'] . '</td>';
				echo '<td>' . $row['make'] . '</td>';
				echo '<td>' . $row['ministry'] . '</td>';
				echo '<td>' . $row['os'] . '</td>';
				echo '<td>' . $row['software'] . '</td>';
				echo '<td>' . $row['username'] . '</td>';
				echo '<td>' . $row['offNumber'] . '</td>';
				echo '<td>' . $row['Total'] . '</td>';
				?>
				<td><a href="update_computer.php?sNumber=<?php echo $row['sNumber']?>"><img src="images/update-icon.png" width="35" height="35" border="0" /></a></td>
				<td><a href="delete_computer.php?sNumber=<?php echo $row['sNumber']?>" onclick="return confirm('Are you sure you wish to delete this Record?');"><img src="images/delete-icon.png" width="35" height="35" border="0" /></a></td>
				<?php
				  echo "</tr>";
				  
				  //echo "<form>";
				  echo $row['Total'];
				  //echo '<td>' .  . '</td>';
				  //echo "</form>";

	} }
	
?>

